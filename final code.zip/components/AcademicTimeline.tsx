import { timelineEvents } from "@/data/timeline";

export default function AcademicTimeline() {
  return (
   <section
  id="timeline"
  className="scroll-mt-24 ..."
>
      <div className="mx-auto max-w-5xl px-6">
        <div className="mb-12 text-center">
          <h2 className="text-4xl font-bold">
            Academic Journey
          </h2>

          <p className="mt-3 text-gray-600">
            Key milestones throughout my research career.
          </p>
        </div>

        <div className="relative border-l-4 border-blue-600 pl-8">
          {timelineEvents.map((event) => (
            <div key={event.id} className="relative mb-12">
              <div className="absolute -left-[42px] h-6 w-6 rounded-full border-4 border-blue-600 bg-white"></div>

              <span className="inline-block rounded-full bg-blue-100 px-3 py-1 text-sm font-semibold text-blue-700">
                {event.year}
              </span>

              <h3 className="mt-3 text-2xl font-bold">
                {event.title}
              </h3>

              <p className="mt-3 text-gray-600">
                {event.description}
              </p>

              <span className="mt-4 inline-block rounded-full bg-slate-100 px-3 py-1 text-sm text-slate-700">
                {event.category}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}