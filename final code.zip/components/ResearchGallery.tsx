import Image from "next/image";
import { galleryItems } from "@/data/gallery";

export default function ResearchGallery() {
  return (
    <section
  id="gallery"
  className="scroll-mt-24 ..."
>
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-12">
          <h2 className="text-4xl font-bold">
            Research Gallery
          </h2>

          <p className="mt-3 text-gray-600">
            Highlights from our microrobotics and microfluidics research.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {galleryItems.map((item) => (
            <div
              key={item.id}
              className="overflow-hidden rounded-2xl bg-white shadow transition hover:shadow-lg"
            >
              <Image
                src={item.image}
                alt={item.title}
                width={500}
                height={350}
                className="h-56 w-full object-cover"
              />

              <div className="p-5">
                <h3 className="text-lg font-semibold">
                  {item.title}
                </h3>

                <p className="mt-3 text-sm text-gray-600">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}