import Link from "next/link";
import { academicProfiles } from "@/data/profile";

export default function AcademicProfiles() {
  return (
    <section id="profiles" className="bg-white py-20">
      <div className="max-w-6xl mx-auto px-6">

        <div className="mb-12">
          <h2 className="text-4xl font-bold">
            Academic Profiles
          </h2>

          <p className="mt-3 text-gray-600">
            Find my research profiles and professional networks.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">

          {academicProfiles.map((profile) => (
            <Link
              key={profile.name}
              href={profile.url}
              target="_blank"
              className="rounded-xl border bg-slate-50 p-8 text-center hover:shadow-md transition"
            >
              <div className="text-5xl">
                {profile.icon}
              </div>

              <h3 className="mt-4 text-xl font-semibold">
                {profile.name}
              </h3>
            </Link>
          ))}

        </div>

      </div>
    </section>
  );
}