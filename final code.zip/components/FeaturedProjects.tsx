import Link from "next/link";
import { ArrowRight, Cpu, Microscope, Brain } from "lucide-react";

const projects = [
  {
    icon: <Microscope className="w-8 h-8 text-blue-600" />,
    title: "Magnetic Microrobot-Based Microfluidic Systems",
    description:
      "Development of programmable magnetic microrobots for targeted drug delivery, cell manipulation, and biomedical microfluidic applications.",
    technologies: [
      "Microfluidics",
      "Magnetic Actuation",
      "Microrobotics",
    ],
    status: "Completed",
  },
  {
    icon: <Brain className="w-8 h-8 text-purple-600" />,
    title: "AI-Assisted Microfluidic Flow Optimization",
    description:
      "Machine learning and deep learning models for intelligent prediction and optimization of complex microfluidic flow behavior.",
    technologies: [
      "Artificial Intelligence",
      "Deep Learning",
      "CFD",
    ],
    status: "Research",
  },
  {
    icon: <Cpu className="w-8 h-8 text-emerald-600" />,
    title: "Biomedical Lab-on-Chip Platform",
    description:
      "Design and fabrication of integrated MEMS-based lab-on-chip systems for next-generation biomedical diagnostics.",
    technologies: [
      "MEMS",
      "Biomedical Engineering",
      "Microfabrication",
    ],
    status: "Completed",
  },
];

export default function FeaturedProjects() {
  return (
    <section className="py-24 bg-white">

      <div className="max-w-7xl mx-auto px-6">

        <div className="text-center">

          <span className="text-blue-600 font-semibold uppercase tracking-wider">
            Research Projects
          </span>

          <h2 className="mt-3 text-4xl font-bold text-slate-900">
            Featured Research Projects
          </h2>

          <p className="mt-5 text-lg text-gray-600 max-w-3xl mx-auto">
            Research projects spanning Microfluidics, Artificial Intelligence,
            Biomedical Engineering, Magnetic Microrobotics and Smart Healthcare.
          </p>

        </div>

        <div className="grid lg:grid-cols-3 gap-8 mt-16">

          {projects.map((project) => (

            <div
              key={project.title}
              className="
              rounded-3xl
              border
              bg-white
              p-8
              shadow-sm
              hover:shadow-xl
              hover:-translate-y-2
              transition-all
              duration-300
            "
            >

              <div className="flex justify-between items-center">

                {project.icon}

                <span className="rounded-full bg-green-100 text-green-700 px-3 py-1 text-sm font-semibold">
                  {project.status}
                </span>

              </div>

              <h3 className="mt-6 text-2xl font-bold text-slate-900">
                {project.title}
              </h3>

              <p className="mt-5 text-gray-600 leading-7">
                {project.description}
              </p>

              <div className="mt-6 flex flex-wrap gap-2">

                {project.technologies.map((tech) => (

                  <span
                    key={tech}
                    className="
                    rounded-full
                    bg-slate-100
                    px-3
                    py-1
                    text-sm
                    font-medium
                    text-slate-700
                  "
                  >
                    {tech}
                  </span>

                ))}

              </div>

            </div>

          ))}

        </div>

        <div className="text-center mt-14">

          <Link
            href="/projects"
            className="
            inline-flex
            items-center
            gap-2
            rounded-xl
            bg-blue-600
            px-8
            py-4
            font-semibold
            text-white
            hover:bg-blue-700
            transition
          "
          >
            View All Projects
            <ArrowRight className="w-5 h-5" />
          </Link>

        </div>

      </div>

    </section>
  );
}