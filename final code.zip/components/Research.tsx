import {
  BrainCircuit,
  Droplets,
  Microscope,
  HeartPulse,
  Waves,
  Target,
  ArrowRight,
} from "lucide-react";

import {
  researchAreas,
  researchHighlights,
  researchVision,
  researchGoals,
} from "@/data/research";

const icons = {
  Droplets,
  BrainCircuit,
  Microscope,
  HeartPulse,
  Waves,
};

export default function Research() {
  return (
    <section className="max-w-7xl mx-auto px-6 py-14">

      {/* Header */}

      <div className="mb-14">

        <span className="text-blue-600 font-semibold uppercase tracking-widest">
          Research
        </span>

        <h1 className="mt-2 text-4xl font-bold text-slate-900">
          Research Areas & Vision
        </h1>

        <p className="mt-5 max-w-4xl text-lg leading-8 text-slate-600">
          My research focuses on integrating robotics, microfluidics,
          computational modeling, and artificial intelligence to develop
          intelligent microsystems for biomedical and healthcare applications.
        </p>

      </div>

      {/* Research Vision */}

      <div className="rounded-3xl bg-gradient-to-r from-blue-700 to-indigo-700 p-10 text-white shadow-lg">

        <div className="flex items-center gap-4">

          <Target size={32} />

          <h2 className="text-3xl font-bold">
            {researchVision.title}
          </h2>

        </div>

        <p className="mt-6 text-lg leading-8 text-blue-100">
          {researchVision.description}
        </p>

      </div>

      {/* Research Areas */}

      <div className="mt-16">

        <h2 className="text-3xl font-bold text-slate-900">
          Research Areas
        </h2>

        <div className="mt-8 grid gap-8 md:grid-cols-2 xl:grid-cols-3">

          {researchAreas.map((area) => {
            const Icon =
              icons[area.icon as keyof typeof icons] || Microscope;

            return (
              <div
                key={area.id}
                className="rounded-2xl border bg-white p-7 shadow-sm transition hover:-translate-y-1 hover:shadow-xl"
              >
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-blue-100">

                  <Icon
                    size={28}
                    className="text-blue-700"
                  />

                </div>

                <h3 className="mt-6 text-xl font-bold text-slate-900">
                  {area.title}
                </h3>

                <p className="mt-4 text-slate-600 leading-7">
                  {area.description}
                </p>

              </div>
            );
          })}

        </div>

      </div>

      {/* Research Highlights */}

      <div className="mt-20">

        <h2 className="text-3xl font-bold text-slate-900">
          Research Highlights
        </h2>

        <div className="mt-8 grid gap-6 lg:grid-cols-2">

          {researchHighlights.map((highlight) => (

            <div
              key={highlight.title}
              className="rounded-xl border bg-white p-6 shadow-sm"
            >

              <div className="flex gap-3">

                <ArrowRight
                  className="mt-1 text-blue-600"
                  size={20}
                />

                <div>

                  <h3 className="font-semibold text-xl">
                    {highlight.title}
                  </h3>

                  <p className="mt-2 leading-7 text-slate-600">
                    {highlight.description}
                  </p>

                </div>

              </div>

            </div>

          ))}

        </div>

      </div>

      {/* Future Research */}

      <div className="mt-20 rounded-3xl border bg-slate-50 p-10">

        <h2 className="text-3xl font-bold text-slate-900">
          Future Research Directions
        </h2>

        <div className="mt-8 space-y-4">

          {researchGoals.map((goal) => (

            <div
              key={goal}
              className="flex gap-4"
            >

              <Target
                size={18}
                className="mt-1 text-blue-600 shrink-0"
              />

              <span className="text-lg text-slate-700">
                {goal}
              </span>

            </div>

          ))}

        </div>

      </div>

    </section>
  );
}