import { reviewerData } from "@/data/reviewer";

export default function ReviewerSection() {
  return (
    <section
  id="reviewer"
  className="scroll-mt-24 ..."
>
      <div className="max-w-6xl mx-auto">

        <h2 className="text-3xl font-bold text-center mb-10">
          Academic Service
        </h2>

        <p className="text-center text-gray-600 mb-8">
          Peer reviewer for international journals in biomedical
          engineering, robotics, and related research domains.
        </p>


        <div className="grid md:grid-cols-2 gap-6">

          {reviewerData.map((reviewer, index) => (
            <div
              key={index}
              className="border rounded-xl p-6 shadow-sm hover:shadow-md transition"
            >

              <h3 className="text-xl font-semibold">
                {reviewer.journal}
              </h3>

              {reviewer.impactFactor && (
                <p className="text-sm text-blue-600 mt-2">
                  {reviewer.impactFactor}
                </p>
              )}

              <div className="flex justify-between mt-4 text-gray-600">

                <span>
                  {reviewer.year}
                </span>

                <span>
                  {reviewer.reviews}
                </span>

              </div>

            </div>
          ))}

        </div>

      </div>
    </section>
  );
}